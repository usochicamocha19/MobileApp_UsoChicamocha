package com.example.testusoandroidstudio_1_usochicamocha.data.local.entity
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.testusoandroidstudio_1_usochicamocha.domain.model.Form

@Entity(tableName = "pending_forms")
data class FormEntity(
    @PrimaryKey(autoGenerate = true) val localId: Int = 0,
    val UUID: String,
    val timestamp: Long,
    val machineId: Long,
    val userId: Long,
    val hourmeter: String,
    val leakStatus: String,
    val brakeStatus: String,
    val beltsPulleysStatus: String,
    val tireLanesStatus: String,
    val carIgnitionStatus: String,
    val electricalStatus: String,
    val mechanicalStatus: String,
    val temperatureStatus: String,
    val oilStatus: String,
    val hydraulicStatus: String,
    val coolantStatus: String,
    val structuralStatus: String,
    val expirationDateFireExtinguisher: String,
    val observations: String,
    val greasingAction: String,
    val greasingObservations: String,
    val isUnexpected: Boolean,
    var isSynced: Boolean = false
)

fun FormEntity.toDomain(): Form {
    return Form(
        localId = localId,
        UUID = this.UUID,
        timestamp = timestamp,
        machineId = machineId,
        userId = userId,
        hourmeter = hourmeter,
        leakStatus = leakStatus,
        brakeStatus = brakeStatus,
        beltsPulleysStatus = beltsPulleysStatus,
        tireLanesStatus = tireLanesStatus,
        carIgnitionStatus = carIgnitionStatus,
        electricalStatus = electricalStatus,
        mechanicalStatus = mechanicalStatus,
        temperatureStatus = temperatureStatus,
        oilStatus = oilStatus,
        hydraulicStatus = hydraulicStatus,
        coolantStatus = coolantStatus,
        structuralStatus = structuralStatus,
        expirationDateFireExtinguisher = expirationDateFireExtinguisher,
        observations = observations,
        greasingAction = this.greasingAction,
        greasingObservations = this.greasingObservations,
        isUnexpected = this.isUnexpected,
        isSynced = isSynced
    )
}
