package com.example.testusoandroidstudio_1_usochicamocha.ui.main

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.testusoandroidstudio_1_usochicamocha.domain.model.Form
import com.example.testusoandroidstudio_1_usochicamocha.domain.model.Maintenance
import com.example.testusoandroidstudio_1_usochicamocha.ui.shared.ConnectionStatusTopBar
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    networkStatus: Boolean,
    viewModel: MainViewModel = hiltViewModel(),
    onLogout: () -> Unit,
    onNavigateToForm: () -> Unit,
    onNavigateToLogs: () -> Unit,
    onNavigateToImprevisto: () -> Unit,
    onNavigateToMantenimiento: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    // --- LaunchedEffects (sin cambios) ---
    LaunchedEffect(uiState.logoutCompleted) {
        if (uiState.logoutCompleted) {
            onLogout()
            viewModel.onLogoutCompleted()
        }
    }

    LaunchedEffect(uiState.syncMachinesMessage) {
        uiState.syncMachinesMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            viewModel.clearSyncMachinesMessage()
        }
    }

    // LaunchedEffect para el mensaje de sincronización de aceites (NUEVO)
    LaunchedEffect(uiState.syncOilsMessage) {
        uiState.syncOilsMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            viewModel.clearSyncOilsMessage()
        }
    }

    LaunchedEffect(uiState.syncFormsMessage) {
        uiState.syncFormsMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            viewModel.clearSyncFormsMessage()
        }
    }

    LaunchedEffect(uiState.syncMaintenanceMessage) {
        uiState.syncMaintenanceMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            viewModel.clearSyncMaintenanceMessage()
        }
    }

    Scaffold(
        topBar = {
            Column {
                ConnectionStatusTopBar(isConnected = networkStatus)
                TopAppBar(
                    title = { Text("Menú Principal") },
                    actions = {
                        IconButton(onClick = onNavigateToLogs) {
                            Icon(Icons.Filled.History, contentDescription = "Ver Logs")
                        }
                        IconButton(onClick = { viewModel.onLogoutClick() }) {
                            Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = "Cerrar Sesión")
                        }
                    }
                )
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            AvailableFormsCard(
                onNavigateToForm = onNavigateToForm,
                onNavigateToImprevisto = onNavigateToImprevisto,
                onNavigateToMantenimiento = onNavigateToMantenimiento
            )

            PendingMaintenanceCard(
                pendingMaintenance = uiState.pendingMaintenanceForms,
                isSyncing = uiState.isSyncingMaintenance,
                onSyncClicked = { viewModel.onSyncMaintenanceClicked() }
            )

            PendingFormsCard(
                pendingForms = uiState.pendingForms,
                isSyncingForms = uiState.isSyncingForms,
                onSyncFormsClicked = { viewModel.onSyncFormsClicked() }
            )

            // --- NUEVA TARJETA DE ACCIONES DE SINCRONIZACIÓN ---
            SyncActionsCard(
                isSyncingMachines = uiState.isSyncingMachines,
                onSyncMachinesClicked = { viewModel.onSyncMachinesClicked() },
                isSyncingOils = uiState.isSyncingOils,
                onSyncOilsClicked = { viewModel.onSyncOilsClicked() }
            )
        }
        if (uiState.showLogoutDialog) {
            LogoutConfirmationDialog(
                onConfirm = { viewModel.onConfirmLogout() },
                onDismiss = { viewModel.onDismissLogoutDialog() }
            )
        }
    }
}

// --- NUEVO COMPOSABLE PARA LAS ACCIONES DE SINCRONIZACIÓN ---
@Composable
fun SyncActionsCard(
    isSyncingMachines: Boolean,
    onSyncMachinesClicked: () -> Unit,
    isSyncingOils: Boolean,
    onSyncOilsClicked: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Sincronización de Datos", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                // Botón para sincronizar máquinas
                Button(
                    onClick = onSyncMachinesClicked,
                    enabled = !isSyncingMachines,
                    modifier = Modifier.weight(1f)
                ) {
                    if (isSyncingMachines) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                    } else {
                        Text("Sinc. Máquinas")
                    }
                }
                // Botón para sincronizar aceites
                Button(
                    onClick = onSyncOilsClicked,
                    enabled = !isSyncingOils,
                    modifier = Modifier.weight(1f)
                ) {
                    if (isSyncingOils) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                    } else {
                        Text("Sinc. Aceites")
                    }
                }
            }
        }
    }
}


// --- PENDING FORMS CARD (MODIFICADO) ---
// Se eliminó la lógica y los parámetros de la sincronización de máquinas.
@Composable
fun PendingFormsCard(
    pendingForms: List<Form>,
    isSyncingForms: Boolean,
    onSyncFormsClicked: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Inspecciones Pendientes", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                Button(
                    onClick = onSyncFormsClicked,
                    enabled = !isSyncingForms,
                    shape = RoundedCornerShape(16.dp),
                ) {
                    if (isSyncingForms) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                    } else {
                        Icon(Icons.Default.Sync, contentDescription = "Sincronizar Inspecciones")
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            if (pendingForms.isEmpty()) {
                Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                    Text("No hay inspecciones pendientes.")
                }
            } else {
                LazyColumn(
                    modifier = Modifier.height(150.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(pendingForms) { form ->
                        PendingFormItem(form = form)
                    }
                }
            }
        }
    }
}


// --- EL RESTO DE COMPOSABLES (SIN CAMBIOS) ---

@Composable
fun AvailableFormsCard(
    onNavigateToForm: () -> Unit,
    onNavigateToImprevisto: () -> Unit,
    onNavigateToMantenimiento: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Formularios disponibles", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedButton(onClick = onNavigateToForm, modifier = Modifier.fillMaxWidth()) {
                Text("Inspección Maquinaria", fontSize = 18.sp)
            }
            OutlinedButton(onClick = onNavigateToImprevisto, modifier = Modifier.fillMaxWidth()) {
                Text("Imprevisto Maquinaria", fontSize = 18.sp)
            }
            OutlinedButton(onClick = onNavigateToMantenimiento, modifier = Modifier.fillMaxWidth()) {
                Text("Mantenimiento", fontSize = 18.sp)
            }
        }
    }
}

@Composable
fun PendingMaintenanceCard(
    pendingMaintenance: List<Maintenance>,
    isSyncing: Boolean,
    onSyncClicked: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Mantenimientos Pendientes", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                Button(
                    onClick = onSyncClicked,
                    enabled = !isSyncing,
                    shape = RoundedCornerShape(16.dp),
                ) {
                    if (isSyncing) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                    } else {
                        Icon(Icons.Default.Sync, contentDescription = "Sincronizar Mantenimientos")
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            if (pendingMaintenance.isEmpty()) {
                Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                    Text("No hay mantenimientos pendientes.")
                }
            } else {
                LazyColumn(
                    modifier = Modifier.height(150.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(pendingMaintenance) { maintenance ->
                        PendingMaintenanceItem(maintenance = maintenance)
                    }
                }
            }
        }
    }
}

@Composable
fun PendingMaintenanceItem(maintenance: Maintenance) {
    val sdf = SimpleDateFormat("HH:mm - dd/MM/yyyy", Locale.getDefault())
    val formattedDate = sdf.format(Date(maintenance.dateTime))
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("Mantenimiento (${maintenance.type})", fontWeight = FontWeight.Bold)
        Text(formattedDate)
    }
}

@Composable
fun PendingFormItem(form: Form) {
    val sdf = SimpleDateFormat("HH:mm - dd/MM/yyyy", Locale.getDefault())
    val formattedDate = sdf.format(Date(form.timestamp))
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("Inspección", fontWeight = FontWeight.Bold)
        Text(formattedDate)
    }
}

@Composable
fun LogoutConfirmationDialog(
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cerrar Sesión") },
        text = { Text("¿Seguro desea salir? Esto cerrará la sesión actual.") },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
            ) {
                Text("Salir")
            }
        },
        dismissButton = {
            Button(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}