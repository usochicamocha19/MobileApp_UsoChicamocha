package com.example.testusoandroidstudio_1_usochicamocha.domain.model

data class Oil(
    val id: Int,
    val type: String,
    val name: String
)