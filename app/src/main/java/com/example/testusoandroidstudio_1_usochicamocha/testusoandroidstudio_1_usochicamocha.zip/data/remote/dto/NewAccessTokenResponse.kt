package com.example.testusoandroidstudio_1_usochicamocha.data.remote.dto

data class NewAccessTokenResponse(
    val accessToken: String
)