package com.example.testusoandroidstudio_1_usochicamocha.domain.model

data class UserSession(
    val accessToken: String?,
    val refreshToken: String?
)
