package com.example.testusoandroidstudio_1_usochicamocha.data.remote.dto

data class LoginRequest(
    val username: String,
    val password: String
)
