package com.example.testusoandroidstudio_1_usochicamocha.domain.model

data class LogEntry(
    val timestamp: Long,
    val message: String
)