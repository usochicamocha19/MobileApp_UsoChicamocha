package com.example.testusoandroidstudio_1_usochicamocha

import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.*
import com.example.testusoandroidstudio_1_usochicamocha.data.workers.SyncDataWorker
import dagger.hilt.android.HiltAndroidApp
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@HiltAndroidApp
// La corrección está aquí: se eliminó el parámetro del constructor.
class MyApplication : Application(), Configuration.Provider {

    @Inject
    lateinit var workerFactory: HiltWorkerFactory

    // Esta función es la forma correcta de proveer la configuración.
    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    override fun onCreate() {
        super.onCreate()
        scheduleBackgroundSync()
    }

    private fun scheduleBackgroundSync() {
        // 1. Definimos las restricciones: solo se ejecuta si hay internet.
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        // 2. Creamos la petición periódica (mínimo 15 minutos).
        val syncRequest = PeriodicWorkRequestBuilder<SyncDataWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .build()

        // 3. Planificamos el trabajo de forma única para no duplicarlo.
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "background_sync_worker",
            ExistingPeriodicWorkPolicy.KEEP, // Mantiene el trabajo existente si ya está planificado
            syncRequest
        )
    }
}