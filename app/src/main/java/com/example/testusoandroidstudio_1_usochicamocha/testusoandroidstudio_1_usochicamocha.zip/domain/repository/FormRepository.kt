package com.example.testusoandroidstudio_1_usochicamocha.domain.repository

import com.example.testusoandroidstudio_1_usochicamocha.domain.model.Form
import kotlinx.coroutines.flow.Flow

interface FormRepository {
    fun getPendingForms(): Flow<List<Form>>
    suspend fun saveFormLocally(form: Form)
    suspend fun syncForm(form: Form): Result<Unit>
   }