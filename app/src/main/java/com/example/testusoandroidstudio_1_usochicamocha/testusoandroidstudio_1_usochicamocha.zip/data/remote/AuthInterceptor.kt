package com.example.testusoandroidstudio_1_usochicamocha.data.remote

import com.example.testusoandroidstudio_1_usochicamocha.data.local.TokenManager
import com.example.testusoandroidstudio_1_usochicamocha.domain.repository.AuthRepository
import com.example.testusoandroidstudio_1_usochicamocha.util.AppLogger
import com.example.testusoandroidstudio_1_usochicamocha.util.JwtUtils
import dagger.Lazy
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.Response
import javax.inject.Inject

class AuthInterceptor @Inject constructor(
    private val tokenManager: TokenManager,
    private val authRepository: Lazy<AuthRepository>,
    private val appLogger: AppLogger
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val originalRequest = chain.request()

        // IMPORTANT: Prevent recursion for the refresh token endpoint itself.
        // This request should not be intercepted with auth headers or trigger a refresh.
        if (originalRequest.url.toString().contains("api/v1/auth/token/refresh")) {
            appLogger.log("Realizando petición (refresh token)")
            return chain.proceed(originalRequest)
        }

        appLogger.log("Verificando tokens")
        val accessToken = runBlocking { tokenManager.getAccessToken().first() }

        // Proactive token refresh logic
        if (accessToken != null && JwtUtils.isTokenExpired(accessToken, "Access Token")) {
            appLogger.log("Access token vencido")
            appLogger.log("Intentando obtener access token")
            val refreshResult = runBlocking { authRepository.get().refreshTokenIfNecessary() }
            if (refreshResult.isSuccess) {
                appLogger.log("Access token obtenido")
                val newAccessToken = runBlocking { tokenManager.getAccessToken().first() }
                return chain.proceed(
                    originalRequest.newBuilder()
                        .header("Authorization", "Bearer $newAccessToken")
                        .build()
                )
            } else {
                runBlocking { authRepository.get().logout() }
            }
        }

        val requestBuilder = originalRequest.newBuilder()
        if (accessToken != null) {
            requestBuilder.header("Authorization", "Bearer $accessToken")
        }
        appLogger.log("Realizando petición (${originalRequest.url.encodedPath})")
        return chain.proceed(requestBuilder.build())
    }
}