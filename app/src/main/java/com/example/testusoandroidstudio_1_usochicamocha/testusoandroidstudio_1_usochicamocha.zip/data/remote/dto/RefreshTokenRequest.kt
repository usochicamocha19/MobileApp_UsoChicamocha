package com.example.testusoandroidstudio_1_usochicamocha.data.remote.dto

data class RefreshTokenRequest(
    val refreshToken: String
)
