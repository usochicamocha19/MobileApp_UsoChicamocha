package com.example.testusoandroidstudio_1_usochicamocha.util

class Constants {
}