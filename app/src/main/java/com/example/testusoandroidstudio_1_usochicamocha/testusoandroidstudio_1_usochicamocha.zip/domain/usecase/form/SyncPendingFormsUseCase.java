package com.example.testusoandroidstudio_1_usochicamocha.domain.usecase.form;

public class SyncPendingFormsUseCase {
}
