package com.example.testusoandroidstudio_1_usochicamocha.data.workers

import android.content.Context
import android.util.Log
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.testusoandroidstudio_1_usochicamocha.domain.usecase.auth.SessionStatus
import com.example.testusoandroidstudio_1_usochicamocha.domain.usecase.auth.ValidateSessionUseCase
import com.example.testusoandroidstudio_1_usochicamocha.domain.usecase.form.GetPendingFormsUseCase
import com.example.testusoandroidstudio_1_usochicamocha.domain.usecase.form.SyncFormUseCase
import com.example.testusoandroidstudio_1_usochicamocha.domain.usecase.machine.SyncMachinesUseCase
import com.example.testusoandroidstudio_1_usochicamocha.domain.usecase.maintenance.GetPendingMaintenanceFormsUseCase
import com.example.testusoandroidstudio_1_usochicamocha.domain.usecase.maintenance.SyncMaintenanceFormsUseCase
import com.example.testusoandroidstudio_1_usochicamocha.domain.usecase.oil.SyncOilsUseCase
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first

@HiltWorker
class SyncDataWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted workerParams: WorkerParameters,
    // Hilt inyectará todas las dependencias que el worker necesita
    private val validateSessionUseCase: ValidateSessionUseCase,
    private val getPendingFormsUseCase: GetPendingFormsUseCase,
    private val syncFormUseCase: SyncFormUseCase,
    private val getPendingMaintenanceFormsUseCase: GetPendingMaintenanceFormsUseCase,
    private val syncMaintenanceFormsUseCase: SyncMaintenanceFormsUseCase,
    private val syncMachinesUseCase: SyncMachinesUseCase,
    private val syncOilsUseCase: SyncOilsUseCase
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        Log.d("SyncDataWorker", "Iniciando trabajo de sincronización...")

        // 1. Validar la sesión antes de hacer cualquier cosa.
        val sessionStatus = validateSessionUseCase()
        if (sessionStatus == SessionStatus.EXPIRED) {
            Log.d("SyncDataWorker", "Sesión expirada. No se puede sincronizar.")
            return Result.failure() // Falla si no hay sesión válida.
        }
        Log.d("SyncDataWorker", "Sesión válida. Procediendo con la sincronización.")

        try {
            // 2. PRIORIDAD 1: Sincronizar Inspecciones Pendientes
            val pendingForms = getPendingFormsUseCase().first() // Obtenemos la lista actual
            if (pendingForms.isNotEmpty()) {
                Log.d("SyncDataWorker", "Sincronizando ${pendingForms.size} inspecciones pendientes...")
                pendingForms.forEach { form -> syncFormUseCase(form) }
                Log.d("SyncDataWorker", "Inspecciones sincronizadas. Trabajo completado.")
                return Result.success() // Termina el trabajo por este ciclo
            }

            // 3. PRIORIDAD 2: Sincronizar Mantenimientos Pendientes
            val pendingMaintenance = getPendingMaintenanceFormsUseCase().first()
            if (pendingMaintenance.isNotEmpty()) {
                Log.d("SyncDataWorker", "Sincronizando ${pendingMaintenance.size} mantenimientos pendientes...")
                pendingMaintenance.forEach { maintenance -> syncMaintenanceFormsUseCase(maintenance) }
                Log.d("SyncDataWorker", "Mantenimientos sincronizados. Trabajo completado.")
                return Result.success() // Termina el trabajo por este ciclo
            }

            // 4. PRIORIDAD 3: Sincronizar Datos Maestros (Máquinas y Aceites)
            Log.d("SyncDataWorker", "No hay pendientes. Sincronizando datos maestros...")
            syncMachinesUseCase()
            syncOilsUseCase()
            Log.d("SyncDataWorker", "Datos maestros sincronizados. Trabajo completado.")

            return Result.success()

        } catch (e: Exception) {
            Log.e("SyncDataWorker", "Error durante la sincronización: ${e.message}")
            return Result.retry() // Intenta de nuevo más tarde si algo falla
        }
    }
}